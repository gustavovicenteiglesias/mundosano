export interface Macs{
    id_mac:number;
    nombre:string;
    sql_deleted:number;
    last_modified:number;
}