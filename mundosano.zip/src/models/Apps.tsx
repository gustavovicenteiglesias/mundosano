export interface Apps{
    id_app:number;
    nombre:string;
    sql_deleted:number;
    last_modified:number;
}