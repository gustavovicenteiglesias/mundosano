export interface MotivoDeDerivacion{
    id_motivo:number;
    nombre:string;
    //sql_deleted
d:number;
   
last_modified:number;}