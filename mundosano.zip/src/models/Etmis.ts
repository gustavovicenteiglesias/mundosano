export interface Etmis{
    id_etmi:number;
    nombre:string;
    sql_deleted:number;
    last_modified:number;
}