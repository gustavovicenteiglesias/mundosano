export interface NivelesAcceso{
    id_nivel_acceso :number;
    acceso:string;
    //sql_deleted
d:number;
   
last_modified:number;
}