export interface Origenes{
    id_origenes:number;
    nombre:string;
    //sql_deleted
d:number;
   
last_modified:number;}