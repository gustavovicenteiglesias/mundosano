export interface IdSegunDevice{
    id_device?:number;
    nro_device:string;
	min_id:number;
	max_id:number;
	sql_deleted:number;
	last_modified:number;
}