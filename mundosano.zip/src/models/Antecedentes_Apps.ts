export interface Antecedentes_Apps {
    id_antecedente: number;
    id_app: number;
   sql_deleted:number;
   last_modified: number;
    //usuario_modified: number;
}

export const InicialAntecedentes_Apps:Antecedentes_Apps={
    id_antecedente: 0,
    id_app: 0,
    sql_deleted: 0,
    last_modified: 0
}