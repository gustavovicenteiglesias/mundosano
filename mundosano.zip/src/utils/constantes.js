const NOMBRE_BB_DD="triplefrontera";
const BASE_URL = "https://areco.gob.ar:9535/api"//'https://apipampadelindio.cfl401areco.ar/api';
export{NOMBRE_BB_DD,BASE_URL}